#pragma once
class movie�heater
{
	int lounge[10][16];
	int countOfSoldTikets;
public:
	movie�heater();
	void SaveSeat(int rowNum,int seatNum);
	void PrintLounge();
};

